import { Injectable } from '@angular/core';

@Injectable()
export class BrokersService {
  codigoBroker : any;
  datAlteracao: any;
  nomeBroker: any;
  datInclusao: any;
}


